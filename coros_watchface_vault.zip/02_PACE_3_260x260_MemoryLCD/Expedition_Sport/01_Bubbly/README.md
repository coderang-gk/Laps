# Expedition Sport (Bubbly)

**Target Hardware**: COROS PACE 3 (260×260 Memory LCD)
**Font Family**: `google_sans_flex_bubbly.ttf` (Bubbly)
**Color Palette**: Pixel Mint (Primary: `#A8E6CF`, Accent: `#56C596`, Background: AMOLED `#000000`)

## Included Files

- `Expedition_Sport_Bubbly.bin`: Hardware binary ready for direct flashing or offline installation.
- `Expedition_Sport_Bubbly.zip`: Universal CorosLink DIY template archive (`info.json` + `config.txt` + sprites).
- `Expedition_Sport_Bubbly_active.png`: High-resolution 1:1 hardware preview in daylight active mode.
- `Expedition_Sport_Bubbly_aod.png`: High-resolution Always-On Display (AOD) hollow wireframe preview.

## How to Install

### Option 1: Using Laps Mobile App (Direct BLE)
1. Open **Laps** on your Android device.
2. Navigate to the **Watch Face** tab.
3. Select **Expedition Sport** with **Bubbly** font.
4. Tap **⚡ Sync Watch** to flash directly over Bluetooth in ~20 seconds.

### Option 2: Using CorosLink (Web Bluetooth / Desktop)
1. Connect your COROS watch to [CorosLink](https://watchfaces.coroslink.com).
2. Click **Import Watch Face** and select `Expedition_Sport_Bubbly.zip` (or `Expedition_Sport_Bubbly.bin`).
3. Click **Sync to Watch**.
